<?php if (!defined('FW')) die('Forbidden');

wp_enqueue_script(
    'kerge-theme-shortcode-info-list-2',
    plugin_dir_url( __FILE__ ) . 'static/js/scripts.js'
);
