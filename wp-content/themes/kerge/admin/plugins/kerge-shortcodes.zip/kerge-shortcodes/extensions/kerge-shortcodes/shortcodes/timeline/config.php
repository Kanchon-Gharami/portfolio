<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Timeline', 'kerge-shortcodes' ),
	'description' => esc_html__( 'Timeline Information (Education, Experience...)', 'kerge-shortcodes' ),
	'tab'         => esc_html__( 'Kerge Elements', 'kerge-shortcodes' ),
);